﻿
/** String table (English) */
GLOBAL.labels.set({
	menu: {
    main: { en:"Main Menu" },
		menu1: { en:"Menu 1"},
		menu2: { en:"Menu 2"},
    test: { en:"Test Menu" },
		test1: { en:"Test 1"},
		test2: { en:"Test 2"}
	}
});
