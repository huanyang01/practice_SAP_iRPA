﻿
//---------------------------------------------------
// Data Structures
//---------------------------------------------------
// ----------- rootData -------------------
ctx.dataManager({
	rootData :
	{
		SAPGUIData : 
		{
			pSAPEasyAccessUData : 
			{
				oGuiOkCodeField : ''
			}
			, pUserMaintenanceIniData : 
			{
				edUser : ''
			}
		}
	}
});
var rootData = ctx.dataManagers.rootData.create() ;

// ----------- rootData_SAPGUIData -------------------
ctx.dataManager({
	rootData_SAPGUIData :
	{
		pSAPEasyAccessUData : 
		{
			oGuiOkCodeField : ''
		}
		, pUserMaintenanceIniData : 
		{
			edUser : ''
		}
	}
});
var rootData_SAPGUIData = ctx.dataManagers.rootData_SAPGUIData.create() ;

// ----------- rootData_SAPGUIData_pSAPEasyAccessUData -------------------
ctx.dataManager({
	rootData_SAPGUIData_pSAPEasyAccessUData :
	{
		oGuiOkCodeField : ''
	}
});
var rootData_SAPGUIData_pSAPEasyAccessUData = ctx.dataManagers.rootData_SAPGUIData_pSAPEasyAccessUData.create() ;

// ----------- rootData_SAPGUIData_pUserMaintenanceIniData -------------------
ctx.dataManager({
	rootData_SAPGUIData_pUserMaintenanceIniData :
	{
		edUser : ''
	}
});
var rootData_SAPGUIData_pUserMaintenanceIniData = ctx.dataManagers.rootData_SAPGUIData_pUserMaintenanceIniData.create() ;


//---------------------------------------------------
// Settings Structure
//---------------------------------------------------

//---------------------------------------------------
// Functional Events Declaration
//---------------------------------------------------

//---------------------------------------------------
// 
//---------------------------------------------------
